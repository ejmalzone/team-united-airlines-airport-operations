package com.example.xian;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
