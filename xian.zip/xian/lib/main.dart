import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:xian/r.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
        designSize: const Size(640, 1344),
        builder: (context, child) {
          return MaterialApp(
            title: 'Flutter Demo',
            theme: ThemeData(
              primarySwatch: Colors.blue,
            ),
            home: const MyHomePage(title: 'Flutter Demo Home Page'),
          );
        });
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.black,
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Text(
            //   "UNITED",
            //   style: TextStyle(fontSize: 24.w, color: Color(0xff023388)),
            // ),
            // Icon(
            //   Icons.ac_unit,
            //   color: Color(0xff023388),
            //   size: 40.w,
            // ),
            Image.asset(
              R.imgPng,
              height: 50.w,
              width: 250.w,
            ),
          ],
        ),
        centerTitle: true,
      ),
      body: GestureDetector(
        onTap: () {
          FocusScope.of(context).requestFocus(FocusNode());
        },
        behavior: HitTestBehavior.opaque,
        child: Container(
          child: Column(
            children: [
              // Container(
              //   color: Colors.black,
              //   height: 134.w,
              //   child: Center(
              //     child: ,
              //   ),
              // ),
              Expanded(
                child: Container(
                  width: 1.sw,
                  color: Color(0xff327cc1),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      SizedBox(
                        height: 234.w,
                      ),
                      Text(
                        "Welcome to",
                        style: TextStyle(fontSize: 40.w, color: Colors.white),
                      ),
                      Text(
                        "Airports",
                        style: TextStyle(fontSize: 40.w, color: Colors.white),
                      ),
                      Text(
                        "Operations",
                        style: TextStyle(fontSize: 40.w, color: Colors.white),
                      ),
                      Text(
                        "TRAINING PORTAL",
                        style: TextStyle(fontSize: 40.w, color: Colors.white),
                      ),
                      SizedBox(
                        height: 50.w,
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("Login ID"),
                          SizedBox(
                            height: 16.w,
                          ),
                          Container(
                            width: 420.w,
                            height: 60.w,
                            color: Colors.white,
                            child: Center(
                              child: TextField(
                                decoration: InputDecoration(),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 20.w,
                          ),
                          Text("Password"),
                          SizedBox(
                            height: 16.w,
                          ),
                          Container(
                            width: 420.w,
                            height: 60.w,
                            color: Colors.white,
                            child: Center(
                              child: TextField(
                                decoration: InputDecoration(),
                              ),
                            ),
                          ),
                        ],
                      ),
                      GestureDetector(
                        onTap: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => SecondPage()));
                        },
                        behavior: HitTestBehavior.opaque,
                        child: Container(
                          margin: EdgeInsets.only(top: 30.w),
                          width: 227.w,
                          height: 40.w,
                          color: Color(0xff5611a9),
                          child: Center(
                              child: Text(
                            "Login",
                            style:
                                TextStyle(fontSize: 20.w, color: Colors.white),
                          )),
                        ),
                      ),
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}

class SecondPage extends StatefulWidget {
  @override
  SecondPageState createState() => new SecondPageState();
}

class SecondPageState extends State<SecondPage> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.black,
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              "Portal Selection",
              style: TextStyle(fontSize: 24.w, color: Colors.white),
            ),
          ],
        ),
        centerTitle: true,
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(
            height: 234.w,
          ),
          Text(
            "SELECT YOUR PORTAL",
            style: TextStyle(fontSize: 24.w, color: Colors.black),
          ),
          SizedBox(
            height: 56.w,
          ),
          Container(
            width: 1.sw,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                buildItem(
                    Image.asset(
                      R.img3Png,
                      height: 70.w,
                      width: 70.w,
                    ),
                    // Icon(
                    //   Icons.airplane_ticket_rounded,
                    //   size: 70.w,
                    //   color: Colors.black,
                    // ),
                    Text(
                      "Custom Service",
                      style: TextStyle(fontSize: 20.w, color: Colors.black),
                    )),
                SizedBox(
                  width: 80.w,
                ),
                buildItem(
                  Image.asset(
                    R.img2Png,
                    height: 70.w,
                    width: 70.w,
                  ),
                  Text(
                    "Ramp Service",
                    style: TextStyle(fontSize: 20.w, color: Colors.black),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 50.w,
          ),
          buildItem(
              // Icon(
              //   Icons.ac_unit_sharp,
              //   size: 70.w,
              //   color: Color(0xff073693),
              // ),
              Image.asset(
                R.img1Png,
                height: 70.w,
                width: 70.w,
              ),
              Text(
                "Admin",
                style: TextStyle(fontSize: 20.w, color: Colors.black),
              )),
        ],
      ),
    );
  }

  Widget buildItem(Widget one, Widget two) {
    return Container(
      width: 223.w,
      height: 246.w,
      decoration: BoxDecoration(
          color: Color(0xffd9d9d9), borderRadius: BorderRadius.circular(24.w)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          one,
          SizedBox(
            height: 15.w,
          ),
          two
        ],
      ),
    );
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
  }
}
