class R {
 /// ![](http://127.0.0.1:2227/assets/img.png)
 static const String imgPng = 'assets/img.png';
 /// ![](http://127.0.0.1:2227/assets/img_1.png)
 static const String img1Png = 'assets/img_1.png';
 /// ![](http://127.0.0.1:2227/assets/img_2.png)
 static const String img2Png = 'assets/img_2.png';
 /// ![](http://127.0.0.1:2227/assets/img_3.png)
 static const String img3Png = 'assets/img_3.png';

 static const values = [
     imgPng,
     img1Png,
     img2Png,
     img3Png,
 ];
}
